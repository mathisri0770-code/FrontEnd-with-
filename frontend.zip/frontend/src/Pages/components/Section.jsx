import React from "react";
import styles from "./Section.module.css";

export default function Section({ title, highlight, children }) {
  return (
    <section className={styles.section}>
      <h2>
        {title.split(" ").map((word, i) =>
          word === highlight ? (
            <span key={i} className={styles.highlight}>
              {word}
            </span>
          ) : (
            word + " "
          )
        )}
      </h2>
      {children}
    </section>
  );
}
