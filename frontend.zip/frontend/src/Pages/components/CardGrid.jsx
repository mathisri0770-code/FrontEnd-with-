import React from "react";
import styles from "./CardGrid.module.css";

export default function CardGrid({ items, cardType }) {
  return (
    <div className={styles.grid}>
      {items.map((item, idx) => {
        if (cardType === "image") {
          return (
            <img
              key={idx}
              src={item.image}
              alt={item.title || "Event"}
              className={styles.imageCard}
            />
          );
        }
        return (
          <div
            key={idx}
            className={`${styles.card} ${
              cardType === "gradient" ? styles.gradient : ""
            } ${cardType === "alt" ? styles.alt : ""} ${
              cardType === "small" ? styles.small : ""
            }`}
          >
            {item.icon && <div className={styles.icon}>{item.icon}</div>}
            <p>{item.title}</p>
          </div>
        );
      })}
    </div>
  );
}
