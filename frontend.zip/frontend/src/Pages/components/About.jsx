import React from "react";
import styles from "./About.module.css";

export default function About() {
  const teamRoles = ["CEO", "CFO", "Manager", "HR"];
  const links = [
    "www.linkedin.com",
    "www.x.com",
    "www.whatsapp.com",
    "www.instagram.com",
    "www.facebook.com",
    "www.freesound.com",
  ];

  return (
    <div className={styles.about}>
      <p>
        We're passionate about helping individuals find fulfilling careers. Our
        experienced counselors offer personalized advice to help you make
        informed decisions every step of your journey.
      </p>
      <div className={styles.grid}>
        <div>
          {teamRoles.map((role) => (
            <div key={role}>{role}</div>
          ))}
        </div>
        <div>
          {links.map((link) => (
            <a
              href={`https://${link}`}
              key={link}
              target="_blank"
              rel="noreferrer"
            >
              {link}
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
