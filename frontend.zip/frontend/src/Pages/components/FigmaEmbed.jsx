import React from "react";

export default function FigmaEmbed() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
      {/* Figma Embed */}
      <iframe
        style={{ border: "1px solid rgba(0, 0, 0, 0.1)" }}
        width="800"
        height="450"
        src="https://embed.figma.com/design/IuiEqgpaOfjbd52RutLBZw/Untitled?node-id=2018-160&embed-host=share"
        allowFullScreen
        title="Figma Design"
      ></iframe>

      {/* Placeholder Image */}
      <img
        src="https://via.placeholder.com/200x150"
        alt="Placeholder"
        style={{
          borderRadius: "8px",
          border: "1px solid #ccc",
          width: "200px",
          height: "150px",
        }}
      />
    </div>
  );
}
