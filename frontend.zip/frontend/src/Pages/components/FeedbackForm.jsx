import React, { useState } from "react";
import styles from "./FeedbackForm.module.css";

export default function FeedbackForm() {
  const [feedback, setFeedback] = useState("");

  const handleSubmit = () => {
    if (!feedback.trim()) return alert("Please enter feedback!");
    alert("Feedback submitted: " + feedback);
    setFeedback("");
  };

  return (
    <div>
      <textarea
        value={feedback}
        onChange={(e) => setFeedback(e.target.value)}
        placeholder="Enter your feedback"
        className={styles.textarea}
      />
      <button onClick={handleSubmit} className={styles.submitBtn}>
        Submit
      </button>
    </div>
  );
}
