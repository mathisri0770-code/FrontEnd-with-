import React from "react";
import styles from "./Hero.module.css";
import FigmaEmbed from "./FigmaEmbed";

export default function Hero() {
  return (
    <div className={styles.hero}>
      <div className={styles.heroContent}>
        <FigmaEmbed />
        <div>
          <h1>
            <span className={styles.highlight}>CAREER</span> COUNSELLING
            <hr />
          </h1>
          <p>One Stop Solution for All Your Career Related Issues</p>
        </div>
      </div>
    </div>
  );
}
