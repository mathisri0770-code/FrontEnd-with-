export default [
  { title: "CLUB", icon: "↗" },
  { title: "CLUB", icon: "↗" },
  { title: "CLUB", icon: "↗" },
];
