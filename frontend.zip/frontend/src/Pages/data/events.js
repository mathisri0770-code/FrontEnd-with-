export default [
  { background: "linear-gradient(135deg, #7a5fff, #45aaf2)", title: "Event 1" },

  { background: "linear-gradient(135deg, #7a5fff, #45aaf2)", title: "Event 2" },

  { background: "linear-gradient(135deg, #7a5fff, #45aaf2)", title: "Event 3" },

  { background: "linear-gradient(135deg, #7a5fff, #45aaf2)", title: "Event 4" },
];
