export default [
  { title: "Event 1" },
  { title: "Event 2" },
  { title: "Event 3" },
];
