export default [
  { title: "MENTORSHIP", icon: "↗" },
  { title: "COURSES", icon: "↗" },
  { title: "CLUB", icon: "↗" },
  { title: "EVENTS UPCOMING", icon: "↗" },
  { title: "INTERNSHIP", icon: "↗" },
  { title: "HIRING UPDATES", icon: "↗" },
];
