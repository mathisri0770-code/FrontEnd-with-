import React from "react";
import Hero from "./Pages/components/Hero";
import Section from "./Pages/components/Section";
import CardGrid from "./Pages/components/CardGrid";
import FeedbackForm from "./Pages/components/FeedbackForm";
import About from "./Pages/components/About";
import eventsData from "./Pages/data/events";
import servicesData from "./Pages/data/services";
import currentServices from "./Pages/data/currentServices";
import registrationData from "./Pages/data/registration";
import styles from "./App.module.css";
import FigmaEmbed from "./Pages/components/FigmaEmbed";

export default function App() {
  return (
    <div className={styles.body}>
      <FigmaEmbed /> <Hero />
      <Section title="Services We Offer" highlight="OFFER">
        <CardGrid items={servicesData} cardType="gradient" />
      </Section>
      <Section title="Our Current Services" highlight="SERVICES">
        <CardGrid items={currentServices} cardType="alt" />
      </Section>
      <Section title="Registration">
        <CardGrid items={registrationData} cardType="small" />
      </Section>
      <Section title="Event & Webinar Updates" highlight="UPDATES">
        <CardGrid items={eventsData} cardType="image" />
      </Section>
      <Section title="Feedback Section">
        <FeedbackForm />
      </Section>
      <Section title="About Us" highlight="US">
        <About />
      </Section>
    </div>
  );
}
